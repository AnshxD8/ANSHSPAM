<h1 align="center"><b>[⚡] 𝐀𝐍𝐒𝐇 𝐒𝐏𝐀𝐌𝐙 🥵 [⚡]</b></h1>

<h4 align="center"> 𝐀 𝐏𝐎𝐖𝐄𝐑𝐅𝐔𝐋 𝐒𝐏𝐀𝐌𝐁𝐎𝐓𝐒</h4>

<p align="center"><a href="https://t.me/Saif_Dictator"><img src="https://graph.org/file/33ed260fcfc79eb82838b.jpg" width="400"></a></p>


> ⭐️ Thanks to everyone for using this op Dead spam bot. That is the greatest pleasure we have !


# ᴅᴇᴘʟᴏʏᴍᴇɴᴛ


<details>
<summary><b>ᴅᴇᴘʟᴏʏ ᴛᴏ ʜᴇʀᴏᴋᴜ</b></summary>
<br>

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/AnshxD8/AXSPAMBOT)

</details>


<details>
<summary><b>sᴜᴘᴘᴏʀᴛ</b></summary>
<br>

<a href="https://t.me/THE_INDRAPRASTHA"><img src="https://img.shields.io/badge/Join-Telegram%20Channel-red.svg?logo=Telegram"></a>

</details>
